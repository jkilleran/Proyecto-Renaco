--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.13 (Homebrew)
-- Dumped by pg_dump version 14.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE suppliers_db;
--
-- Name: suppliers_db; Type: DATABASE; Schema: -; Owner: mac
--

CREATE DATABASE suppliers_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE suppliers_db OWNER TO mac;

\connect suppliers_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_users_role; Type: TYPE; Schema: public; Owner: mac
--

CREATE TYPE public.enum_users_role AS ENUM (
    'Cliente',
    'Suplidor',
    'Administrador'
);


ALTER TYPE public.enum_users_role OWNER TO mac;

--
-- Name: enum_users_user_type; Type: TYPE; Schema: public; Owner: mac
--

CREATE TYPE public.enum_users_user_type AS ENUM (
    'Cliente',
    'Suplidor',
    'Administrador'
);


ALTER TYPE public.enum_users_user_type OWNER TO mac;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: administradores; Type: TABLE; Schema: public; Owner: mac
--

CREATE TABLE public.administradores (
    user_id integer NOT NULL,
    admin_code character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.administradores OWNER TO mac;

--
-- Name: clientes; Type: TABLE; Schema: public; Owner: mac
--

CREATE TABLE public.clientes (
    user_id integer NOT NULL,
    cliente_code character varying(50) NOT NULL,
    company_name character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.clientes OWNER TO mac;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: mac
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    role_name character varying(50) NOT NULL
);


ALTER TABLE public.roles OWNER TO mac;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: mac
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO mac;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mac
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: suplidores; Type: TABLE; Schema: public; Owner: mac
--

CREATE TABLE public.suplidores (
    user_id integer NOT NULL,
    suplidor_code character varying(50) NOT NULL,
    company_name character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.suplidores OWNER TO mac;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: mac
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    address text,
    phone character varying(20),
    email character varying(255),
    connected_users integer DEFAULT 0
);


ALTER TABLE public.suppliers OWNER TO mac;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: mac
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.suppliers_id_seq OWNER TO mac;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mac
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: mac
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(100) NOT NULL,
    user_type character varying(20) NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now(),
    CONSTRAINT users_user_type_check CHECK (((user_type)::text = ANY ((ARRAY['Cliente'::character varying, 'Suplidor'::character varying, 'Administrador'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO mac;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: mac
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO mac;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mac
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: mac
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(100),
    full_name character varying(100),
    status boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.usuarios OWNER TO mac;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: mac
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO mac;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mac
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: usuarios_roles; Type: TABLE; Schema: public; Owner: mac
--

CREATE TABLE public.usuarios_roles (
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.usuarios_roles OWNER TO mac;

--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: administradores; Type: TABLE DATA; Schema: public; Owner: mac
--

COPY public.administradores (user_id, admin_code, created_at) FROM stdin;
\.
COPY public.administradores (user_id, admin_code, created_at) FROM '$$PATH$$/3733.dat';

--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: mac
--

COPY public.clientes (user_id, cliente_code, company_name, created_at) FROM stdin;
\.
COPY public.clientes (user_id, cliente_code, company_name, created_at) FROM '$$PATH$$/3731.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: mac
--

COPY public.roles (id, role_name) FROM stdin;
\.
COPY public.roles (id, role_name) FROM '$$PATH$$/3727.dat';

--
-- Data for Name: suplidores; Type: TABLE DATA; Schema: public; Owner: mac
--

COPY public.suplidores (user_id, suplidor_code, company_name, created_at) FROM stdin;
\.
COPY public.suplidores (user_id, suplidor_code, company_name, created_at) FROM '$$PATH$$/3732.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: mac
--

COPY public.suppliers (id, name, code, address, phone, email, connected_users) FROM stdin;
\.
COPY public.suppliers (id, name, code, address, phone, email, connected_users) FROM '$$PATH$$/3723.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: mac
--

COPY public.users (id, username, password, email, user_type, "createdAt", "updatedAt") FROM stdin;
\.
COPY public.users (id, username, password, email, user_type, "createdAt", "updatedAt") FROM '$$PATH$$/3725.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: mac
--

COPY public.usuarios (id, username, password, email, full_name, status, created_at) FROM stdin;
\.
COPY public.usuarios (id, username, password, email, full_name, status, created_at) FROM '$$PATH$$/3729.dat';

--
-- Data for Name: usuarios_roles; Type: TABLE DATA; Schema: public; Owner: mac
--

COPY public.usuarios_roles (user_id, role_id) FROM stdin;
\.
COPY public.usuarios_roles (user_id, role_id) FROM '$$PATH$$/3730.dat';

--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mac
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mac
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 17, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mac
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mac
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 1, false);


--
-- Name: administradores administradores_admin_code_key; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.administradores
    ADD CONSTRAINT administradores_admin_code_key UNIQUE (admin_code);


--
-- Name: administradores administradores_pkey; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.administradores
    ADD CONSTRAINT administradores_pkey PRIMARY KEY (user_id);


--
-- Name: clientes clientes_cliente_code_key; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_cliente_code_key UNIQUE (cliente_code);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (user_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (role_name);


--
-- Name: suplidores suplidores_pkey; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.suplidores
    ADD CONSTRAINT suplidores_pkey PRIMARY KEY (user_id);


--
-- Name: suplidores suplidores_suplidor_code_key; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.suplidores
    ADD CONSTRAINT suplidores_suplidor_code_key UNIQUE (suplidor_code);


--
-- Name: suppliers suppliers_code_key; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_code_key UNIQUE (code);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: usuarios_roles usuarios_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.usuarios_roles
    ADD CONSTRAINT usuarios_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: usuarios usuarios_username_key; Type: CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_username_key UNIQUE (username);


--
-- Name: administradores administradores_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.administradores
    ADD CONSTRAINT administradores_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.usuarios(id);


--
-- Name: clientes clientes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.usuarios(id);


--
-- Name: suplidores suplidores_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.suplidores
    ADD CONSTRAINT suplidores_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.usuarios(id);


--
-- Name: usuarios_roles usuarios_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.usuarios_roles
    ADD CONSTRAINT usuarios_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: usuarios_roles usuarios_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mac
--

ALTER TABLE ONLY public.usuarios_roles
    ADD CONSTRAINT usuarios_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

